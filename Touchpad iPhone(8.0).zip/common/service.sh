#!/system/bin/sh
MODDIR=${0%/*}

# Execute script by tytydraco and his project ktweak, thanks! 
write() {
	# Bail out if file does not exist
	[[ ! -f "$1" ]] && return 1
	
	# Make file writable in case it is not already
	chmod +w "$1" 2> /dev/null

	# Write the new value and bail if there's an error
	if ! echo "$2" > "$1" 2> /dev/null
	then
		echo "Failed: $1 → $2"
		return 1
	fi
}

su -c "cmd settings put global window_animation_scale 1.09"
su -c "cmd settings put global transition_animation_scale 1.09"
su -c "cmd settings put global animator_duration_scale 1.09"
su -c "cmd settings put secure long_press_timeout 150"
su -c "cmd settings put secure multi_press_timeout 150"

sleep 20

# Thông điệp
su -lp 2000 -c "cmd notification post -S bigtext -t '🔥 Hệ thống 🔥' 'Tag' 'Mô-đun đã được áp dụng đúng cách, bây giờ bạn có thể tận hưởng trải nghiệm tốt hơn 😁.'"

# Exit
exit 0