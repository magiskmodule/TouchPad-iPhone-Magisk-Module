#!/bin/sh

# Log create
rm -rf /data/media/0/Android/Iphone/
mkdir /data/media/0/Android/Iphone
IPLOG=/data/media/0/Android/Iphone/logs.txt

check_file() {
  if [[ -f "$1" ]]; then
    return 0
  else
    return 1
  fi
}

read_file_unlock() {
  if check_file "$1"; then
    chmod 444 "$1"
    cat "$1"
  fi
}

write_file_lock() {
  if check_file "$1"; then
    chmod 666 "$1"
    echo "$2" > "$1"
    chmod 444 "$1"
  fi
}
echo -e "[$(date +"%Y-%m-%d %T")] Create Read|Write Function.\n" >> $IPLOG

sleep 10

echo "140" > /sys/devices/virtual/sec/sec_touchscreen/tsp_threshold
echo -e "[$(date +"%Y-%m-%d %T")] Iphone Sensi Settings. \n" >> $IPLOG

echo '19005' > /sys/class/touch/switch/set_touchscreen
echo -e "[$(date +"%Y-%m-%d %T")] Set TouchScreen. \n" >> $IPLOG