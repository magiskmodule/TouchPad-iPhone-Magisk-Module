SKIPMOUNT=false
PROPFILE=true
POSTFSDATA=false
LATESTARTSERVICE=true

REPLACE="
"
ui_print " 
    ____      __                        ______
   /  _/___  / /_  ____  ____  ___     /_  __/
   / // __ \/ __ \/ __ \/ __ \/ _ \     / /   
 _/ // /_/ / / / / /_/ / / / /  __/    / /    
/___/ .___/_/ /_/\____/_/ /_/\___/    /_/     
   /_/                                     "
ui_print " Dev : HenVx "
ui_print " Build : 25-10-2023 "

